const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('nfNative', {
  platform: process.platform,
  tts: (a) => ipcRenderer.invoke('nf:tts', a),
  voices: () => ipcRenderer.invoke('nf:voices'),
  keyGet: () => ipcRenderer.invoke('nf:key:get'),
  keySet: (k) => ipcRenderer.invoke('nf:key:set', k),
  ff: {
    info: () => ipcRenderer.invoke('nf:ff:info'),
    begin: () => ipcRenderer.invoke('nf:ff:begin'),
    chunk: (id, bytes) => ipcRenderer.invoke('nf:ff:chunk', id, bytes),
    cancel: (id) => ipcRenderer.invoke('nf:ff:cancel', id),
    finish: (id, o) => ipcRenderer.invoke('nf:ff:finish', id, o),
    reveal: (p) => ipcRenderer.invoke('nf:ff:reveal', p),
    onProgress: (cb) => { const h = (e, v) => cb(v); ipcRenderer.on('nf:ff:progress', h); return () => ipcRenderer.removeListener('nf:ff:progress', h); }
  }
});
