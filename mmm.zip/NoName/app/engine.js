'use strict';
// No Name — export engine (main process). Wraps a real FFmpeg: hardware H.264 when the PC has it (NVENC / AMF / QuickSync),
// libx264 otherwise. Pure Node (no Electron imports) so it can be tested on its own.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

function findFfmpeg(resourcesPath) {
  const exe = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const cands = [];
  if (resourcesPath) cands.push(path.join(resourcesPath, 'bin', exe));
  cands.push(path.join(__dirname, 'bin', exe));
  for (const c of cands) { try { if (fs.existsSync(c)) return c; } catch (_) {} }
  return exe;                                    // fall back to whatever is on PATH
}

function run(bin, args, opts) {
  return new Promise((resolve) => {
    let out = '', err = '', p;
    try { p = spawn(bin, args, Object.assign({ windowsHide: true }, opts || {})); } catch (e) { return resolve({ code: -1, out, err: String(e) }); }
    p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { err += d; });
    p.on('error', (e) => resolve({ code: -1, out, err: String(e) }));
    p.on('close', (code) => resolve({ code, out, err }));
  });
}

// ordered by preference; each is verified with a real 1-second test encode, because "listed" does not mean "works on this PC"
const ENCODERS = [
  { id: 'h264_nvenc', label: 'NVIDIA NVENC', args: (q) => ['-c:v', 'h264_nvenc', '-preset', 'p5', '-rc', 'vbr', '-cq', String(q + 3), '-b:v', '0', '-profile:v', 'high'] },
  { id: 'h264_amf', label: 'AMD AMF', args: (q) => ['-c:v', 'h264_amf', '-quality', 'quality', '-rc', 'cqp', '-qp_i', String(q + 2), '-qp_p', String(q + 4), '-qp_b', String(q + 5)] },
  { id: 'h264_qsv', label: 'Intel QuickSync', args: (q) => ['-c:v', 'h264_qsv', '-global_quality', String(q + 3), '-preset', 'medium'] },
  { id: 'libx264', label: 'CPU (x264)', args: (q) => ['-c:v', 'libx264', '-preset', 'medium', '-crf', String(q), '-profile:v', 'high'] },
];

let cache = null;
async function detect(ffmpeg) {
  if (cache && cache.ffmpeg === ffmpeg) return cache;
  const ver = await run(ffmpeg, ['-hide_banner', '-version']);
  if (ver.code !== 0) { cache = { ffmpeg, ok: false, error: 'FFmpeg not found', encoders: [] }; return cache; }
  const list = await run(ffmpeg, ['-hide_banner', '-encoders']);
  const have = ENCODERS.filter((e) => new RegExp('\\b' + e.id + '\\b').test(list.out));
  const working = [];
  for (const e of have) {
    const t = await run(ffmpeg, ['-hide_banner', '-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=256x144:rate=30:duration=0.4', '-pix_fmt', 'yuv420p'].concat(e.args(20), ['-f', 'null', '-']));
    if (t.code === 0) working.push(e);
  }
  cache = { ffmpeg, ok: working.length > 0, version: (ver.out.split('\n')[0] || '').slice(0, 80), encoders: working.map((e) => ({ id: e.id, label: e.label })), error: working.length ? '' : 'No working H.264 encoder' };
  return cache;
}

// input: recorded .webm/.mp4 from the editor; opts: { output, fps, durationSec, quality (14..28, lower = better), encoder, onProgress }
async function transcode(ffmpeg, input, opts) {
  const info = await detect(ffmpeg);
  if (!info.ok) return { ok: false, error: info.error };
  const order = opts.encoder ? ENCODERS.filter((e) => e.id === opts.encoder).concat(ENCODERS.filter((e) => e.id !== opts.encoder)) : ENCODERS;
  const usable = order.filter((e) => info.encoders.some((x) => x.id === e.id));
  const q = Math.max(12, Math.min(30, Number(opts.quality) || 18)), fps = Math.max(1, Math.min(120, Math.round(Number(opts.fps) || 30)));
  let last = '';
  for (const enc of usable) {
    const args = ['-hide_banner', '-y', '-v', 'error', '-progress', 'pipe:1', '-nostats', '-i', input,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2:flags=lanczos,format=yuv420p', '-fps_mode', 'cfr', '-r', String(fps),
      '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv']
      .concat(enc.args(q), ['-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', opts.output]);
    const res = await new Promise((resolve) => {
      let err = '', buf = '', p;
      try { p = spawn(ffmpeg, args, { windowsHide: true }); } catch (e) { return resolve({ code: -1, err: String(e) }); }
      p.stdout.on('data', (d) => {
        buf += d; let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          const m = /^out_time_(?:us|ms)=(\d+)/.exec(line);
          if (m && opts.durationSec && opts.onProgress) { const sec = Number(m[1]) / 1e6; opts.onProgress(Math.max(0, Math.min(0.99, sec / opts.durationSec))); }
        }
      });
      p.stderr.on('data', (d) => { err += d; });
      p.on('error', (e) => resolve({ code: -1, err: String(e) }));
      p.on('close', (code) => resolve({ code, err }));
    });
    if (res.code === 0) { let bytes = 0; try { bytes = fs.statSync(opts.output).size; } catch (_) {} return { ok: true, encoder: enc.id, label: enc.label, path: opts.output, bytes }; }
    last = res.err.trim().split('\n').slice(-2).join(' ');
    try { fs.unlinkSync(opts.output); } catch (_) {}
  }
  return { ok: false, error: last || 'Encoding failed' };
}

module.exports = { findFfmpeg, detect, transcode, ENCODERS };
