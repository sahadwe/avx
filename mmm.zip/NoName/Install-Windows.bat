@echo off
setlocal
title Installing No Name
set "VER=33.2.0"
set "DEST=%LOCALAPPDATA%\NoName"
set "TMPZ=%TEMP%\noname-electron.zip"
echo Downloading app runtime (about 115 MB, one time)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://github.com/electron/electron/releases/download/v%VER%/electron-v%VER%-win32-x64.zip' -OutFile '%TMPZ%'"
if errorlevel 1 (echo Download failed. Check your internet and try again. & pause & exit /b 1)
if exist "%DEST%" rmdir /s /q "%DEST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%TMPZ%' '%DEST%'"
del "%TMPZ%" >nul 2>&1
ren "%DEST%\electron.exe" "No Name.exe"
del "%DEST%\resources\default_app.asar" >nul 2>&1
xcopy /e /i /q /y "%~dp0app" "%DEST%\resources\app" >nul
rem ---- FFmpeg export engine (downloaded once, kept in %LOCALAPPDATA%\NoName-ffmpeg so re-installs are fast) ----
set "FFC=%LOCALAPPDATA%\NoName-ffmpeg"
if not exist "%FFC%\ffmpeg.exe" (
  echo Downloading the export engine, FFmpeg (about 200 MB, one time)...
  mkdir "%FFC%" >nul 2>&1
  set "FFZ=%TEMP%\noname-ffmpeg.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip' -OutFile '%TEMP%\noname-ffmpeg.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[IO.Compression.ZipFile]::OpenRead('%TEMP%\noname-ffmpeg.zip'); foreach($e in $z.Entries){ if($e.FullName -like '*/bin/ffmpeg.exe'){ [IO.Compression.ZipFileExtensions]::ExtractToFile($e,'%FFC%\ffmpeg.exe',$true) } }; $z.Dispose()"
  del "%TEMP%\noname-ffmpeg.zip" >nul 2>&1
)
if exist "%FFC%\ffmpeg.exe" (
  mkdir "%DEST%\resources\bin" >nul 2>&1
  copy /y "%FFC%\ffmpeg.exe" "%DEST%\resources\bin\ffmpeg.exe" >nul
) else (
  echo Note: FFmpeg could not be downloaded. The app still works; export will save .webm instead of .mp4.
)
powershell -NoProfile -Command "$s=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $l=$s.CreateShortcut($p+'\No Name.lnk'); $l.TargetPath='%DEST%\No Name.exe'; $l.WorkingDirectory='%DEST%'; $l.IconLocation='%DEST%\resources\app\icon.ico'; $l.Save() }"
echo.
echo Done! "No Name" is on your Desktop and Start menu.
start "" "%DEST%\No Name.exe"
