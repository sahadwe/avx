#!/bin/bash
cd "$(dirname "$0")"
VER=33.2.0
case "$(uname -m)" in arm64) A=arm64;; *) A=x64;; esac
APP="/Applications/No Name.app"
echo "Downloading app runtime (about 100 MB, one time)..."
curl -L -o /tmp/noname-electron.zip "https://github.com/electron/electron/releases/download/v$VER/electron-v$VER-darwin-$A.zip" || { echo "Download failed"; exit 1; }
rm -rf "$APP" /tmp/noname-el && mkdir /tmp/noname-el && unzip -q /tmp/noname-electron.zip -d /tmp/noname-el
mv /tmp/noname-el/Electron.app "$APP"
rm -f "$APP/Contents/Resources/default_app.asar"
cp -R app "$APP/Contents/Resources/app"
cp app/icon.icns "$APP/Contents/Resources/electron.icns"
sed -i '' 's#<string>Electron</string>#<string>No Name</string>#' "$APP/Contents/Info.plist" 2>/dev/null
# keep CFBundleExecutable valid
/usr/libexec/PlistBuddy -c "Set :CFBundleExecutable Electron" "$APP/Contents/Info.plist" 2>/dev/null
xattr -cr "$APP"; codesign --force --deep --sign - "$APP"
rm -rf /tmp/noname-el /tmp/noname-electron.zip
echo "Done! Open No Name from Applications."
open "$APP"
