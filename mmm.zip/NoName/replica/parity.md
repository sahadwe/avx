## Parity: 87.5 / 100

features 87.5  (57 counted, must-haves 20 of 22 done)

Not shippable yet: 2 must-have features are not done.

## By area, weakest first
- ai                            25.0  (2 features)
- performance                   50.0  (2 features)
- effects                       60.0  (2 features)
- enhance                       66.7  (2 features)
- ui                            75.0  (2 features)
- text                          80.0  (5 features)
- audio                         87.5  (8 features)
- timeline                      88.0  (10 features)
- color                         90.0  (4 features)
- project                      100.0  (2 features)
- media                        100.0  (2 features)
- animation                    100.0  (3 features)
- speed                        100.0  (3 features)
- compositing                  100.0  (5 features)
- transitions                  100.0  (2 features)
- overlay                      100.0  (1 features)
- export                       100.0  (2 features)

## Missing, in build order
- [must] performance: Smooth 60fps preview, partial  (governor added; CPU effects remain)
- [must] timeline: Timeline zoom slider + shortcut, partial
- [should] effects: Effects on adjustment layer (affects all below), no
- [should] audio: Voiceover record, partial
- [should] color: Curves + color wheels, partial
- [should] performance: Proxy/low-res preview for heavy clips, partial  (auto-quality governor)
- [should] text: Auto captions (speech to text), partial  (needs online/model - verify)
- [should] text: Text styles/presets, partial
- [should] timeline: Waveform display, partial  (only 7 mentions - check)
- [could] ai: Transcript-based editing, no
- [could] enhance: Enhance/relight, no  (AI-style; approximate with filters)
- [could] ui: Layout switch (vertical workspace), no
- [could] ai: Auto cut silence/filler, partial
- [could] audio: Audio ducking, partial  (2 mentions)
- [could] audio: Pitch/speed/reverb, partial
- [could] timeline: Magnetic/main track gap close, partial

## Left out on purpose (not scored)
- Stock music/video/stickers library: licensed content - cannot clone
- AI avatars/script-to-video/try-on: cloud AI service owned by original
- Direct share to TikTok/Instagram: partner deals
- Cloud sync/templates marketplace: network and user content
