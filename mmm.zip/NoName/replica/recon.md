# Recon: CapCut desktop (Windows/Mac) -> target: No Name (Electron)
Scope: core loop import -> timeline edit -> effects/text/audio -> export. Audience: owner's own app.
Sources: primalvideo.com CapCut desktop tutorial; ishosting.com CapCut review; litcommerce cheat sheet (search result); capcut.com blocked by allowlist.
Limits: no screenshots/account access in this session, so layout detail is from text descriptions; replica/screens/ is empty. Ask user for screenshots of own CapCut for pixel layout.

## Screens
S01 Home/projects | S02 Editor (media/audio/text/stickers/effects/transitions/filters/adjust tabs top-left, player centre, details right, timeline bottom) | S03 Project settings modal | S04 Export dialog | S05 Caption/transcript view | S06 Settings/shortcuts
## Flows
F01 New project -> import -> drag to timeline -> trim/split -> export (happy path ~8 clicks)
F02 Add effect/filter -> drag onto clip or layer above -> tune intensity
F03 Text/captions -> add text clip or auto-captions -> style -> apply all
F04 Audio: add music below video -> fade, normalize, enhance
F05 Colour: filter + adjust (temp/exposure/sat/HSL/curves/wheels) -> apply to all
## Components
Tab rail, media grid, timeline track rows, clip block (handles, waveform), playhead, details panel w/ sliders + keyframe diamond, modal, toast, export dialog.
## Data model (inferred, medium confidence)
Project{name,aspect,res,fps,mediaMode}; Track{type,order,hidden}; Clip{src,in,out,start,speed,keyframes[],effects[],mask,blend}; Effect{type,params}; TextClip; Caption; ExportJob.
## Cannot be cloned (skip rows in CSV)
Stock libraries, cloud AI (avatars, script-to-video), platform sharing, template marketplace.
## Size
M for the gaps; No Name already covers most of the matrix. Hard parts: real-GPU performance, CPU-bound chroma/LUT, auto-captions (needs a speech model).
