/* Smoke test: every toolbar button, on a main clip and on an overlay, must open a non-empty panel (or a known row) without JS errors.
   Run:  NODE_PATH=$(npm root -g) node tests/smoke.js <video.mp4> <overlay.mp4>   (needs playwright)  */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
const [vid, ovid] = process.argv.slice(2);
if (!vid || !ovid) { console.log('usage: node tests/smoke.js main.mp4 overlay.mp4'); process.exit(2); }
(async () => {
  const src = fs.readFileSync(path.join(__dirname, '../app/index.html'), 'utf8');
  /* debug copy only inside the test run: exposes state + render */
  const dbg = path.join(__dirname, '../app/__smoke.html');
  const mk = '  // =========================================================================\n  // v75 — one design-token layer';
  if (src.indexOf(mk) < 0) { console.log('anchor for the debug hook not found (v75 marker moved)'); process.exit(2); }
  fs.writeFileSync(dbg, src.replace(mk, 'window.__st=state;window.__rd=function(){try{redrawIfPaused()}catch(e){};try{render()}catch(e){}};\n' + mk));
  const b = await chromium.launch({ ignoreDefaultArgs: ['--hide-scrollbars'] });
  const fails = []; let checks = 0;
  try {
    for (const target of ['clip', 'overlay']) {
      const p = await b.newPage({ viewport: { width: 480, height: 800 } }); const errs = [];
      p.on('pageerror', (e) => errs.push(e.message.slice(0, 160))); await p.route(/^https?:/, (r) => r.abort());
      await p.goto('file://' + dbg, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(1500);
      await p.setInputFiles('#fileInput', vid); await p.waitForTimeout(1800);
      await p.setInputFiles('#overlayFileInput', ovid); await p.waitForTimeout(2200);
      if (typeof await p.evaluate(() => typeof window.__st) !== 'string' || await p.evaluate(() => typeof window.__st) === 'undefined') { fails.push('debug hook missing'); break; }
      const ids = await p.evaluate(() => [...document.querySelectorAll('#iconToolbar .icon-btn-tool')].map((b) => b.id).filter(Boolean));
      for (const id of ids) {
        if (/toolDelete|toolSplit|toolDuplicateClip|toolSelect|toolFreeze|toolReverse|toolExtractAudio|toolVoice|toolAutoCaption|toolText|toolOverlay|nfg_toov/.test(id)) continue;   // actions, not panels
        await p.evaluate((t) => {
          if (t === 'overlay') { __st.selectedClipId = null; __st.selectedOverlayId = __st.overlays[0].id; } else { __st.selectedOverlayId = null; __st.selectedClipId = __st.clips[0].id; }
          __st.activeToolSection = null; document.body.classList.remove('nf70-props', 'nf70-add', 'nfm-rbrow', 'nfm-trrow'); __rd();
        }, target);
        await p.waitForTimeout(250);
        const vis = await p.evaluate((id) => { const b = document.getElementById(id); return !!b && b.offsetWidth > 0 && !b.disabled; }, id);
        if (!vis) continue;                      // button not offered for this selection: fine
        const before = errs.length; checks++;
        await p.evaluate((id) => document.getElementById(id).click(), id); await p.waitForTimeout(500);
        const res = await p.evaluate(() => {
          const pp = document.getElementById('propsPanel'), sh = document.getElementById('nf70Sh');
          const txt = (pp ? pp.innerText.trim().length : 0), row = ['nfm-rbrow', 'nfm-trrow', 'nfm-ratiorow'].some((c) => document.body.classList.contains(c));
          const rail = document.body.classList.contains('nf70-add');
          return { txt, row, rail, sec: __st.activeToolSection, shown: !!(sh && sh.offsetHeight > 0) };
        });
        const ok = res.txt > 5 || res.row || res.rail || res.sec;
        if (!ok) fails.push(`${target}: ${id} opened nothing (blank panel)`);
        if (errs.length > before) fails.push(`${target}: ${id} threw ${errs.slice(before).join(' | ')}`);
      }
      await p.close();
    }
  } finally { await b.close(); try { fs.unlinkSync(dbg); } catch (_) {} }
  console.log(checks + ' button checks,', fails.length + ' problems'); fails.forEach((f) => console.log(' -', f));
  process.exit(fails.length ? 1 : 0);
})();
