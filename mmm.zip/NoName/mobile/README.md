# No Name — Android + iOS (Capacitor)

Same `index.html` UI, wrapped as a real app for both phones. NOT built or tested yet (no Android SDK / Xcode where this was prepared).

## Android (Windows or Mac)
1. Install Node.js and Android Studio.
2. In this folder: `npm install` then `npm run add:android`
3. `npm run open:android` -> Run on a phone or emulator.
4. After changing `../app/index.html`: `npm run sync`

## iOS (Mac with Xcode only — Apple does not allow iOS builds on Windows)
1. `npm install` then `npm run add:ios`
2. `npm run open:ios` -> Run on iPhone / simulator.

## Known limits (honest)
- Phone WebView does not have the Electron/FFmpeg export (`engine.js`); export there uses the browser path (MediaRecorder).
- Real "CapCut-level" speed needs a native plugin (Android MediaCodec + iOS AVFoundation/Metal) for decode, effects and export.
  That plugin is not written yet. Build/run the app first, measure with the F3 performance HUD, then we add the plugin where it lags.
